LeafRun Pocket Edition
======================
Version: v2.44.99.4 (Rolling Giant peek)

HOW TO PLAY
-----------
Open LeafRun_Pocket_Edition.html in Chrome, Firefox, Edge, or Safari.

This is the classic / standard version of LeafRun.

NEW IN THIS BUILD
-----------------
• Archives tab → The Dead Mall
  Dark abandoned mall until the usual blackout level (30).
  Then lights turn ON (no blackout sequence).
  VHS ghost overlay runs from the start through the whole run
  when Vibrant Visuals is ON (PLAY ▶ · PM 5:40 · MAY.03 2018).

You can unlock Plus features inside this edition with codes:
  PLUS  ·  LEAFRUNPLUS  ·  PLUSDEMO

CONTROLS
--------
• Tap / click or press Space to jump
• Esc or P pauses

CONTENTS
--------
LeafRun_Pocket_Edition.html     — The game
Fonts/                          — Plus Alpha colour font (CC-BY)
Soundtracks/                    — Official menu OST
Sprites/                        — Pixel art + logos
Mods/                           — Modes & features list
THANK_YOU_FOR_PLAYING.txt

No install needed. Everything runs from the HTML file.
